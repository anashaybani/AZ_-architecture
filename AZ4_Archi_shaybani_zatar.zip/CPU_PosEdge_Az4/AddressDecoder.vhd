-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------

-- 
-- Create Date:    07:00:23 09/23/2015 
-- Design Name: 
-- Module Name:    AddressDecoder - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity AddressDecoder is
    Port ( 
           Addr : in  STD_LOGIC_VECTOR (4 downto 0);
           Ram_Active : out  STD_LOGIC;
           Inp_Active : out  STD_LOGIC;
           Out_Active : out  STD_LOGIC
			  );
end AddressDecoder;

architecture Behavioral of AddressDecoder is
signal Inp_Active_sig : std_logic;
signal Out_Active_sig : std_logic;

begin
Out_Active_sig <= '1' when Addr="11101" else '0';--1D
Inp_Active_sig <= '1' when Addr="11110" else '0';--1E

Out_Active <= Out_Active_sig;
Inp_Active <= Inp_Active_sig;

Ram_Active <= '1' when (Out_Active_sig='0' and Inp_Active_sig='0') else '0';
end Behavioral;

