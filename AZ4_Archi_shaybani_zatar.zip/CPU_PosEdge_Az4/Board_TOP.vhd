-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------

-- 
-- Create Date:    05:37:06 10/10/2015 
-- Design Name: 
-- Module Name:    Board_TOP - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
USE ieee.std_logic_unsigned.all; 
USE ieee.numeric_std.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Board_TOP is
port ( 
           Clk             : in  STD_LOGIC;
			  Sw              : in STD_LOGIC_VECTOR(3 downto 0) ;
			  SegD            : out STD_LOGIC_VECTOR(7 downto 0) ;
			  An              : out STD_LOGIC_VECTOR(3 downto 0) ;
			  DIP_SW          : in STD_LOGIC_VECTOR(7 downto 0) ;
           LEDs            : out STD_LOGIC_VECTOR(7 downto 0) 
);
		
end Board_TOP;

architecture Behavioral of Board_TOP is
-----------------------------------------------------------
--- Base Computer ----------------------------------------- 
COMPONENT CPU_Top
    PORT(
		clk      : in std_logic ;
		rst      : in std_logic ;
		InPort   : in std_logic_vector(7 downto 0) ;
		--- Registers -------------------------------------
		OutPort  : out std_logic_vector(7 downto 0) 
        );
 END COMPONENT;
component SevenSeg is
    Port ( GCLK     : in  STD_LOGIC;
			  Reset    : in  STD_LOGIC;
           SegD0    : in  STD_LOGIC_VECTOR(3 downto 0);
           SegD1    : in  STD_LOGIC_VECTOR(3 downto 0);
           SegD2    : in  STD_LOGIC_VECTOR(3 downto 0);
           SegD3    : in  STD_LOGIC_VECTOR(3 downto 0);
           SEG_SEL  : out  STD_LOGIC_VECTOR (4 downto 0);
           SEG_DATA : out  STD_LOGIC_VECTOR (7 downto 0)
			  );
end component;


signal CLK_key       : STD_LOGIC ;
  

-----------------------------------------------------------------
signal OUTR         : STD_LOGIC_VECTOR ( 7 downto	0 ) ;
Signal CNTR_CLK     : STD_LOGIC_VECTOR( 27 downto 0);
Signal RST          : STD_LOGIC ;
signal Manual_Clk   : STD_LOGIC ;
signal Manual_CNTR  : STD_LOGIC_VECTOR ( 7 downto	0 ):=(others=>'0') ;
---------------------------------------------------------------------------------------------------
signal SegD0    : STD_LOGIC_VECTOR(3 downto 0);
Signal SegD1    : STD_LOGIC_VECTOR(3 downto 0);
Signal SegD2    : STD_LOGIC_VECTOR(3 downto 0);
Signal SegD3    : STD_LOGIC_VECTOR(3 downto 0);
signal SEG_SEL  :  STD_LOGIC_VECTOR (4 downto 0);
signal SEG_DATA :  STD_LOGIC_VECTOR (7 downto 0);
signal inPort   :  STD_LOGIC_VECTOR (7 downto 0);
BEGIN
    inPort <= not DIP_SW;
   CPU_Top_U0: CPU_Top PORT MAP (
          rst     => RST,
          InPort  => inPort,
          clk     => Manual_Clk,
          OutPort => OUTR
        );

























CLK_key <= Sw(3) and Sw(2) and Sw(1);
RST <= not Sw(0) ;

LEDs   <=OUTR when (RST='0') else "11111111";

SegD0 <=OUTR(3 downto 0)   when (CLK_key='1') else Manual_CNTR(3 downto 0);
SegD1 <=OUTR(7 downto 4)   when (CLK_key='1') else Manual_CNTR(7 downto 4);
SegD2 <=inPort(3 downto 0) ;
SegD3 <=inPort(7 downto 4) ;
An <= not SEG_SEL(3 downto 0)when (CLK_key='1') else not("00"& SEG_SEL(1 downto 0));
SegD<=not SEG_DATA;



---  Computer -----------------------------------------

		  
SevenSeg_U0: SevenSeg 
    Port Map( 
	        GCLK     => Clk,
			  Reset    => RST,
           SegD0    => SegD0,
           SegD1    => SegD1,
           SegD2    => SegD2,
           SegD3    => SegD3,
           SEG_SEL  => SEG_SEL,
           SEG_DATA => SEG_DATA
			  );
 --- CLK --------------------------------------------------
 utp:Process (CLK) 														 -- Initial Val is -1-
	begin  
	if(clk='1' and clk'event)then 
		Manual_Clk <= '0' ;
		if (CLK_Key= '0' and  CNTR_CLK /= x"26FFFFF" )then  -- If key Pressed and Counter is not full
			CNTR_CLK <= CNTR_CLK + 1 ;	
		elsif(CLK_Key = '1')	then								  -- If Key is not pressed
			CNTR_CLK <= (others=> '0'); 
		elsif (CNTR_CLK = x"26FFFFF" ) then 							  -- If Counter is Full
			Manual_Clk <= '1' ;
			CNTR_CLK <= x"1A00000"; 
		end if ;				
	end if;
 end process;
 --- CLK --------------------------------------------------
 Process (CLK) 														 
	begin  
	if(clk='1' and clk'event)then 
	   if(RST='1')then
		    Manual_CNTR <=(others=>'0');
		elsif(Manual_Clk = '1' )then
		    Manual_CNTR <= Manual_CNTR + 1;
		end if;
	end if;
 end process;
 ----------------------------------------------------------

end Behavioral;

