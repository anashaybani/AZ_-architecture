-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------


-- Create Date:    21:25:16 09/23/2015 
-- Design Name: 
-- Module Name:    MemIO - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
USE ieee.std_logic_unsigned.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MemIO is
    Port ( 
           Addr     : in      STD_LOGIC_VECTOR(4 downto 0);
           Clk      : in      STD_LOGIC;
           Rd       : in      STD_LOGIC;
           Wr       : in      STD_LOGIC;
           Din      : in      STD_LOGIC_VECTOR (7 downto 0);  
           DOut     : out     STD_LOGIC_VECTOR (7 downto 0);  
			  
           inPort   : in      STD_LOGIC_VECTOR (7 downto 0);  
           outPort  : out     STD_LOGIC_VECTOR (7 downto 0)
	 );
end MemIO;

architecture Behavioral of MemIO is
component RAM32x8Bits is
    Port (
           Addr     : in      STD_LOGIC_VECTOR(4 downto 0);
           Clk      : in      STD_LOGIC;
           Rd       : in      STD_LOGIC;
           Wr       : in      STD_LOGIC;
           Din      : in      STD_LOGIC_VECTOR (7 downto 0);  
           DOut     : out     STD_LOGIC_VECTOR (7 downto 0)  
  );  
end component;
component AddressDecoder is
    Port ( 
           Addr : in  STD_LOGIC_VECTOR (4 downto 0);
           Ram_Active : out  STD_LOGIC;
           Inp_Active : out  STD_LOGIC;
           Out_Active : out  STD_LOGIC
			  );
end component;
signal RAM_DOut : std_logic_vector(7 downto 0);
signal Ram_Active : std_logic;
signal Inp_Active : std_logic;
signal Out_Active : std_logic;

begin
RAM32x8Bits_U0: RAM32x8Bits
    Port Map(
           Addr     => Addr,
           Clk      => Clk,
           Rd       => Rd  ,
           Wr       => Wr  ,
           Din      => Din ,
           DOut     => RAM_DOut
  );  

AddressDecoder_U0: AddressDecoder 
    Port Map(
           Addr        => Addr,
           Ram_Active  => Ram_Active,
           Inp_Active => Inp_Active,
           Out_Active => Out_Active
			  );

DOut <= inPort when (Inp_Active='1')else 
        RAM_DOut;
		  
process(Clk)
begin
	if(Clk'event and Clk='1')then
		 if(Out_Active='1' and Wr='1')then
			  outPort <= Din;
		 end if;	  
	end if;		 
end process; 
end Behavioral;

  