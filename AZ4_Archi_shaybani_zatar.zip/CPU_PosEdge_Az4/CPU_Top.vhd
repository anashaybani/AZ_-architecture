-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------



library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_UNSIGNED.ALL;
entity CPU_Top is
	Port (
			Clk     : in  std_logic ;
			Rst     : in  std_logic ;
			InPort  : in  std_logic_vector(7 downto 0) ;
			OutPort : out std_logic_vector(7 downto 0) 
		);
end CPU_Top; 

architecture Behavioral of CPU_Top is
	--- signals -----------------------------------------------
	
	signal LD_AR       : std_logic ;
	signal LD_PC       : std_logic ;
	signal LD_AC       : std_logic ;
	signal LD_IR       : std_logic ;
	signal ALU_LD_Reg1 : std_logic ;
	signal ALU_LD_Reg2 : std_logic ;
	signal Rst_AR      : std_logic ; 
	signal Rst_PC      : std_logic ; 
	signal Rst_AC      : std_logic ; 
	signal Inc_AR      : std_logic ; 
	signal Inc_PC      : std_logic ; 
	signal Inc_AC      : std_logic ; 
	signal Bus_sel     : std_logic_vector(2 downto 0) ;
	signal Mem_Rd      : std_logic ;
	signal Mem_Wr      : std_logic ;
	signal Control_Cmd : std_logic_vector(1 downto 0) ; 
	signal ALU_flags   : std_logic_vector(2 downto 0) ;
	signal AC          : std_logic_vector(7 downto 0) ;
	signal IR          : std_logic_vector(7 downto 0) ;
	                   
	signal Mem_Din     : STD_LOGIC_VECTOR(7 downto 0);
	signal Mem_Dout    : STD_LOGIC_VECTOR(7 downto 0);
	signal Mem_Addr    : STD_LOGIC_VECTOR(4 downto 0);
	                   
	-----------------------------------------------------------
	--- Data_Path ---------------------------------------------
	component DataPath is
		Port (
		--- From OUT ------------------------------------------
		Rst          : in STD_LOGIC;
		inpr         : in STD_LOGIC_VECTOR(7 downto 0);
		Clk          : in STD_LOGIC;
		-------------------------------------------------------
		--- From Control To Rrgisters -------------------------
		LD_AR        : in STD_LOGIC;
		LD_PC        : in STD_LOGIC;
		LD_AC        : in STD_LOGIC;
		LD_IR        : in STD_LOGIC;
		ALU_LD_Reg1  : in STD_LOGIC;
		ALU_LD_Reg2  : in STD_LOGIC;
		Rst_AR       : in STD_LOGIC;
		Rst_PC       : in STD_LOGIC;
		Rst_AC       : in STD_LOGIC;
		Inc_AR       : in STD_LOGIC;
		Inc_PC       : in STD_LOGIC;
		Inc_AC       : in STD_LOGIC;
		-------------------------------------------------------
		--- From Control To BUS -------------------------------
		Bus_sel      : in STD_LOGIC_VECTOR(2 downto 0);
		-------------------------------------------------------
		--- Memory Interface ----------------------------
		Mem_Din      : out STD_LOGIC_VECTOR(7 downto 0);
		Mem_Dout     : in  STD_LOGIC_VECTOR(7 downto 0);
		Mem_Addr     : out STD_LOGIC_VECTOR(4 downto 0);
		-------------------------------------------------------
		--- From Control To Alu -------------------------------
		Control_Cmd  : in STD_LOGIC_VECTOR(1 downto 0) ;
		-------------------------------------------------------
		--- To Control ----------------------------------------
		ALU_flags    : out STD_LOGIC_VECTOR(2 downto 0) ;
		IR           : out STD_LOGIC_VECTOR(7 downto 0);
		ac           : out STD_LOGIC_VECTOR(7 downto 0)
		-------------------------------------------------------
			);
	end component;
	-----------------------------------------------------------
	--- Control_Unit ------------------------------------------
	component Control_Unit is
			Port ( 
		--- From OUT --------------------------------------
		Rst          : in std_logic ;
		Clk          : in std_logic ;
		---------------------------------------------------
		--- From DataPath ---------------------------------
		AC           : in STD_LOGIC_VECTOR(7 downto 0);
		IR           : in STD_LOGIC_VECTOR(7 downto 0); 
		ALU_flags    : in STD_LOGIC_VECTOR(2 downto 0) ;
		---------------------------------------------------
		---------------------------------------------------
		--- To Registers ----------------------------------
		LD_AR        : out STD_LOGIC;
		LD_PC        : out STD_LOGIC;
		LD_AC        : out STD_LOGIC;
		LD_IR        : out STD_LOGIC;
		ALU_LD_Reg1  : out STD_LOGIC;
		ALU_LD_Reg2  : out STD_LOGIC;
		Rst_AR       : out STD_LOGIC;
		Rst_PC       : out STD_LOGIC;
		Rst_AC       : out STD_LOGIC;
		Inc_AR       : out STD_LOGIC;
		Inc_PC       : out STD_LOGIC;
		Inc_AC       : out STD_LOGIC;
		---------------------------------------------------
		--- To BUS ----------------------------------------
		Bus_sel      : out STD_LOGIC_VECTOR(2 downto 0);	
		---------------------------------------------------
		--- To Memory -------------------------------------		
		Mem_Rd       : out STD_LOGIC;
		Mem_Wr       : out STD_LOGIC;
		---------------------------------------------------
		--- To ALU ----------------------------------------		
		Control_Cmd  : out STD_LOGIC_VECTOR(1 downto 0) 
		);
	end component;
	-----------------------------------------------------------
component MemIO is
    Port ( 
           Addr     : in      STD_LOGIC_VECTOR(4 downto 0);
           Clk      : in      STD_LOGIC;
           Rd       : in      STD_LOGIC;
           Wr       : in      STD_LOGIC;
           Din      : in      STD_LOGIC_VECTOR (7 downto 0);  
           DOut     : out     STD_LOGIC_VECTOR (7 downto 0);  
			  
           inPort   : in      STD_LOGIC_VECTOR (7 downto 0);  
           outPort  : out     STD_LOGIC_VECTOR (7 downto 0)
	 );
end component;

	
begin
	--- RAM 32x8 --------------------------------------------------
MemIO_U0: MemIO 
    Port Map( 
           Addr     => Mem_Addr(4 downto 0),
           Clk      => Clk,
           Rd       => Mem_Rd,
           Wr       => Mem_Wr,
           Din      => Mem_Din,
           DOut     => Mem_Dout,   
			  
           inPort   => InPort, 
           outPort  => outPort
	 );

	--- Data Path ---------------------------------------------
	DataPath_U0 : DataPath Port map (
	--- From OUT ------------------------------------------
			Rst => Rst ,
			inpr => InPort ,
			Clk => Clk ,
			-------------------------------------------------------
			--- From Control To Rrgisters -------------------------
			LD_AR => LD_AR ,
			LD_PC => LD_PC ,
			LD_AC => LD_AC ,
			LD_IR => LD_IR ,
			ALU_LD_Reg1 => ALU_LD_Reg1,
			ALU_LD_Reg2 => ALU_LD_Reg2,
			Rst_AR => Rst_AR ,
			Rst_PC => Rst_PC ,
			Rst_AC => Rst_AC ,
			Inc_AR => Inc_AR ,
			Inc_PC => Inc_PC ,
			Inc_AC => Inc_AC ,
			-------------------------------------------------------
			--- From Control To BUS -------------------------------
			Bus_sel =>  Bus_sel ,
			-------------------------------------------------------
		--- Memory Interface ----------------------------
		   Mem_Din      => Mem_Din  ,
		   Mem_Dout     => Mem_Dout ,
		   Mem_Addr     => Mem_Addr ,
			-------------------------------------------------------
			--- From Control To Alu -------------------------------
			Control_Cmd => Control_Cmd ,
			-------------------------------------------------------
			
			ALU_flags => ALU_flags,
			IR => IR ,
			AC => AC 
			-------------------------------------------------------
			); 
	
	-----------------------------------------------------------	
	--- Control -----------------------------------------------
	Control_Unit_U0 : Control_Unit Port map ( 
		--- From OUT --------------------------------------
		Rst   => Rst   ,
		Clk   => Clk   ,
		---------------------------------------------------
		--- From DataPath ---------------------------------
		AC   => AC   ,
		IR   => IR   ,
		ALU_flags => ALU_flags,
		---------------------------------------------------
		---------------------------------------------------
		--- To Registers ----------------------------------
		LD_AR => LD_AR,
		LD_PC => LD_PC,
		LD_AC => LD_AC,
		LD_IR => LD_IR,
		ALU_LD_Reg1 => ALU_LD_Reg1,
		ALU_LD_Reg2 => ALU_LD_Reg2,
		Rst_AR => Rst_AR,
		Rst_PC => Rst_PC,
		Rst_AC => Rst_AC,
		Inc_AR => Inc_AR,
		Inc_PC => Inc_PC,
		Inc_AC => Inc_AC,
		---------------------------------------------------
		--- To BUS ----------------------------------------
		Bus_sel => Bus_sel ,
		---------------------------------------------------
		--- To Memory -------------------------------------		
		Mem_Rd => Mem_Rd ,
		Mem_Wr => Mem_Wr ,
		---------------------------------------------------
		--- To ALU ----------------------------------------		
		Control_Cmd => Control_Cmd 
		);
end Behavioral;