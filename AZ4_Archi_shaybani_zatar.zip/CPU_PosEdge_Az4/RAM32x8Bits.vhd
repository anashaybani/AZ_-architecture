-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
USE ieee.std_logic_unsigned.all;

entity RAM32x8Bits is
    Port (
           Addr     : in      STD_LOGIC_VECTOR(4 downto 0);
           Clk      : in      STD_LOGIC;
           Rd       : in      STD_LOGIC;
           Wr       : in      STD_LOGIC;
           Din      : in      STD_LOGIC_VECTOR (7 downto 0);  
           DOut     : out     STD_LOGIC_VECTOR (7 downto 0)  
  );  
end RAM32x8Bits;

architecture Behavioral of RAM32x8Bits is
Subtype RAM_WORD is std_logic_vector(7 downto 0) ;
Type RAM_TABLE is array ( 0 to 31) of RAM_WORD;
signal RAM: RAM_TABLE := 
         (
          x"1e", x"A6", x"3D", x"40", x"00", x"00", x"FF", x"77", x"88", x"99", x"aa", x"bb", x"cc", x"dd", x"ee", x"ff",
          x"AA", x"11", x"22", x"33", x"44", x"55", x"66", x"77", x"88", x"99", x"aa", x"bb", x"cc", x"dd", x"ee", x"ff"
         );
begin
DOut <=  RAM(conv_integer ( Addr ));
process(Clk)
begin
	if(Clk='1' and Clk'event)then
		if(Wr='1')then
			RAM(conv_integer ( Addr ))<=   Din;	
		end if;		
	end if;	
end process;	
end Behavioral;