-------------------------------------------------------------------
-- Company: University of Isfahan
-- Computer Architecture Laboratory
-- Design a Computer based on PosEdge Board, http://posedge.ir/
-- Laboratory Homepage: http://ui.ac.ir/ShowPage.aspx?page_=form&order=show&lang=1&sub=108&PageId=9984&PageIDF=9306&tempname=computer
-- Designer: Ali Bohlooli, Ph.D.
-- Email: bohlooli@eng.ui.ac.ir , a_bohlooli@yahoo.com
-- HomePage: http://eng.ui.ac.ir/bohlooli
-- HomePage: http://bohlooli.ir
-- Revision Date: 1394/11/01 
-------------------------------------------------------------------

-- Create Date:   15:28:42 12/05/2013
-- Design Name:   
-- Module Name:   mano_computer_tb.vhd
-- Project Name:  CPU_Top_tb
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: mano_computer
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY CPU_Top_tb IS
END CPU_Top_tb;
 
ARCHITECTURE behavior OF CPU_Top_tb IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT CPU_Top
    PORT(
			clk     : in  std_logic ;
			rst     : in  std_logic ;
			InPort  : in  std_logic_vector(7 downto 0) ;
			OutPort : out std_logic_vector(7 downto 0) 
        );
    END COMPONENT;
    

   --Inputs
   signal rst : std_logic := '1';
   signal InPort : std_logic_vector(7 downto 0) := x"AA";
   signal OutPort : std_logic_vector(7 downto 0) ;
   signal clk : std_logic := '0';

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
	rst <= '0' after 150 ns ;
			 
	-- Instantiate the Unit Under Test (UUT)
   uut: CPU_Top PORT MAP (
          rst => rst,
          InPort => InPort,
          clk => clk,
          OutPort => OutPort
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;

END;
